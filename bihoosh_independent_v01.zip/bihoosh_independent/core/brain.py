class Brain:
    """Interface for the local model. Replace reply() with a local inference backend later."""
    def __init__(self): self.name='بی‌هوش'
    def reply(self, message, history=None):
        m=message.strip()
        if not m: return 'پیامت خالی است.'
        if any(x in m.lower() for x in ['سلام','hello','hi']): return 'سلام! 👾 من بی‌هوش هستم. آماده‌ام.'
        if 'اسم' in m and 'تو' in m: return 'اسم من بی‌هوش است 👾'
        return f'پیامت را دریافت کردم: «{m}»\n\nهسته مستقل من آماده است؛ موتور مدل محلی در مرحله بعد به من وصل می‌شود.'
